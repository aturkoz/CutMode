import bpy
import bmesh
from mathutils import Vector, Matrix, kdtree
from bpy_extras import view3d_utils
from .key_geometry import generate_key_object


# ---------------------------------------------------------------------------
# Screen line  ->  world cutting plane
# ---------------------------------------------------------------------------
def get_cutting_plane_from_screen_line(context, line_start, line_end, obj):
    region = context.region
    rv3d = context.space_data.region_3d
    if not region or not rv3d:
        return None, None

    line_start_vec = Vector(line_start)
    line_end_vec = Vector(line_end)

    d_start = view3d_utils.region_2d_to_vector_3d(region, rv3d, line_start_vec)
    d_end = view3d_utils.region_2d_to_vector_3d(region, rv3d, line_end_vec)
    o_start = view3d_utils.region_2d_to_origin_3d(region, rv3d, line_start_vec)
    o_end = view3d_utils.region_2d_to_origin_3d(region, rv3d, line_end_vec)

    if rv3d.is_perspective:
        plane_no = d_start.cross(d_end).normalized()
    else:
        v_origin = o_end - o_start
        plane_no = d_start.cross(v_origin).normalized()

    if plane_no.length < 1e-6:
        return None, None

    line_mid = (line_start_vec + line_end_vec) / 2
    d_mid = view3d_utils.region_2d_to_vector_3d(region, rv3d, line_mid)
    o_mid = view3d_utils.region_2d_to_origin_3d(region, rv3d, line_mid)

    matrix_inv = obj.matrix_world.inverted()
    local_origin = matrix_inv @ o_mid
    local_direction = (matrix_inv.to_3x3() @ d_mid).normalized()

    success, location, normal, index = obj.ray_cast(local_origin, local_direction)
    if success:
        plane_co = obj.matrix_world @ location
    else:
        bbox_center = sum((Vector(b) for b in obj.bound_box), Vector()) / 8
        world_bbox_center = obj.matrix_world @ bbox_center
        t = (world_bbox_center - o_mid).dot(d_mid) / d_mid.dot(d_mid)
        plane_co = o_mid + t * d_mid

    return plane_co, plane_no


# ---------------------------------------------------------------------------
# Bisect + fill (keeps each half solid)
# ---------------------------------------------------------------------------
def bisect_and_fill(obj, plane_co, plane_no, clear_inner, clear_outer):
    bm = bmesh.new()
    bm.from_mesh(obj.data)

    matrix_inv = obj.matrix_world.inverted()
    local_plane_co = matrix_inv @ plane_co
    # Correct world->local normal transform is transpose(world_3x3),
    # NOT transpose(inverse). Matters for rotated / scaled objects.
    local_plane_no = (obj.matrix_world.to_3x3().transposed() @ plane_no).normalized()

    geom = bm.verts[:] + bm.edges[:] + bm.faces[:]
    ret = bmesh.ops.bisect_plane(
        bm, geom=geom,
        plane_co=local_plane_co, plane_no=local_plane_no,
        clear_inner=clear_inner, clear_outer=clear_outer,
    )

    cut_edges = [e for e in ret['geom_cut'] if isinstance(e, bmesh.types.BMEdge)]
    cut_verts = [v for v in ret['geom_cut'] if isinstance(v, bmesh.types.BMVert)]
    local_cut_coords = [v.co.copy() for v in cut_verts]

    if cut_edges:
        filled = None
        try:
            filled = bmesh.ops.holes_fill(bm, edges=cut_edges, sides=0)
        except Exception:
            filled = None
        made = filled.get('faces', []) if filled else []
        if not made:
            # Fallback for tricky loops so the face stays closed (solid).
            try:
                bmesh.ops.triangle_fill(bm, use_beauty=True,
                                        use_dissolve=False, edges=cut_edges)
            except Exception:
                pass
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)

    bm.to_mesh(obj.data)
    obj.data.update()
    bm.free()
    return local_cut_coords


# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------
def make_plane_basis(n):
    """Deterministic orthonormal in-plane axes (u, v) for a given normal n."""
    n = n.normalized()
    up = Vector((0.0, 0.0, 1.0))
    if abs(n.dot(up)) > 0.99:
        up = Vector((1.0, 0.0, 0.0))
    u = n.cross(up).normalized()
    v = n.cross(u).normalized()
    return u, v


def measure_cut_face(world_pts, normal):
    """Return (center, size_u, size_v) for a set of world-space cut points.
    center is the true bounding-box centre of the loop ON the plane."""
    if not world_pts:
        return None, 0.0, 0.0
    c0 = sum(world_pts, Vector()) / len(world_pts)
    u, v = make_plane_basis(normal)
    pu = [(p - c0).dot(u) for p in world_pts]
    pv = [(p - c0).dot(v) for p in world_pts]
    uc = (min(pu) + max(pu)) / 2.0
    vc = (min(pv) + max(pv)) / 2.0
    center = c0 + u * uc + v * vc
    return center, (max(pu) - min(pu)), (max(pv) - min(pv))


def part_side_sign(obj, center, n):
    """Which side of the plane the object's bulk sits on (+/-)."""
    bb = sum((Vector(b) for b in obj.bound_box), Vector()) / 8
    c = obj.matrix_world @ bb
    return (c - center).dot(n)


def apply_boolean_modifier(target_obj, tool_obj, operation):
    tool_obj.hide_viewport = False
    bpy.ops.object.select_all(action='DESELECT')
    target_obj.select_set(True)
    bpy.context.view_layer.objects.active = target_obj
    mod = target_obj.modifiers.new(name="Dovetail_Bool", type='BOOLEAN')
    mod.operation = operation
    mod.object = tool_obj
    mod.solver = 'EXACT'
    bpy.ops.object.modifier_apply(modifier=mod.name)


# ---------------------------------------------------------------------------
# THE joint builder -- shared by the cut (auto) and the manual button.
# Everything is derived from the exact cut data, so the connector is
# correctly sized (relative to the face), centred and oriented.
# ---------------------------------------------------------------------------
def build_joint(context, part_a, part_b, center, normal, size_u, size_v, settings):
    if context.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    n = normal.normalized()
    u, v = make_plane_basis(n)

    minor = min(size_u, size_v)
    if minor <= 1e-6:
        minor = max(size_u, size_v, 1.0)

    scale_xy = settings['scale_xy']
    scale_z = settings['scale_z']
    clearance = settings['clearance']
    count = max(1, int(settings['count']))
    key_type = settings['key_type']
    flip = settings['flip']

    # --- size RELATIVE to the cut cross-section, kept modest & clamped ---
    base = minor * 0.30 * scale_xy
    if count > 1:
        base *= 0.8
    base = max(min(base, minor * 0.5), minor * 0.05)
    protrusion = base * 1.0 * scale_z
    embed = protrusion * 0.35

    # --- decide which part gets the male peg (peg points AWAY from it) ---
    sign_a = part_side_sign(part_a, center, n)
    if sign_a <= 0:
        male_part, female_part = part_a, part_b
    else:
        male_part, female_part = part_b, part_a
    if flip:
        male_part, female_part = female_part, male_part

    # --- distribute `count` keys along the longer in-plane axis ---
    if size_u >= size_v:
        major_axis, major_ext = u, size_u
    else:
        major_axis, major_ext = v, size_v
    span = major_ext * 0.6
    if count == 1:
        offsets = [0.0]
    else:
        offsets = [(-span / 2.0 + span * i / (count - 1)) for i in range(count)]

    # rotation whose columns are (u, v, n): local X->u, Y->v, Z->n
    R = Matrix(((u.x, v.x, n.x, 0.0),
                (u.y, v.y, n.y, 0.0),
                (u.z, v.z, n.z, 0.0),
                (0.0, 0.0, 0.0, 1.0)))

    males, females = [], []
    for off in offsets:
        pos = center + major_axis * off
        base_pos = pos - n * embed          # embed the base slightly into the male part
        mat = Matrix.Translation(base_pos) @ R

        mk = generate_key_object(key_type, "CutMode_Male", base, base,
                                 protrusion + embed, clearance=0.0)
        context.collection.objects.link(mk)
        mk.matrix_world = mat
        males.append(mk)

        fk = generate_key_object(key_type, "CutMode_Female", base, base,
                                 protrusion + embed * 2.0, clearance=clearance)
        context.collection.objects.link(fk)
        fk.matrix_world = mat
        females.append(fk)

    context.view_layer.update()

    ok = True
    err = ""
    try:
        for mk in males:
            apply_boolean_modifier(male_part, mk, 'UNION')
        for fk in females:
            apply_boolean_modifier(female_part, fk, 'DIFFERENCE')
    except Exception as e:
        ok = False
        err = str(e)

    for o in males + females:
        if o.name in bpy.data.objects:
            bpy.data.objects.remove(o, do_unlink=True)

    return ok, err


# ---------------------------------------------------------------------------
# Fallback for the manual button when no stored cut data is present.
# Returns (center, normal, size_u, size_v) in world space.
# ---------------------------------------------------------------------------
def find_contact_plane(obj_A, obj_B):
    mesh_A = obj_A.data
    mesh_B = obj_B.data
    mw_A = obj_A.matrix_world
    mw_B = obj_B.matrix_world

    if not mesh_B.vertices:
        return None, None, 0.0, 0.0

    kd = kdtree.KDTree(len(mesh_B.vertices))
    for i, vb in enumerate(mesh_B.vertices):
        kd.insert(mw_B @ vb.co, i)
    kd.balance()

    threshold = 0.05
    contact = []
    for va in mesh_A.vertices:
        w = mw_A @ va.co
        co, index, dist = kd.find(w)
        if co is not None and dist < threshold:
            contact.append(w)

    if len(contact) < 3:
        return None, None, 0.0, 0.0

    c0 = sum(contact, Vector()) / len(contact)

    # normal = nearest A face normal to the contact centre
    try:
        nmat = mw_A.to_3x3().inverted().transposed()
    except ValueError:
        nmat = mw_A.to_3x3()
    best_n = Vector((0.0, 0.0, 1.0))
    min_d = float('inf')
    for face in mesh_A.polygons:
        fc = mw_A @ face.center
        d = (fc - c0).length
        if d < min_d:
            min_d = d
            best_n = (nmat @ face.normal).normalized()

    center, size_u, size_v = measure_cut_face(contact, best_n)
    return center, best_n, size_u, size_v
