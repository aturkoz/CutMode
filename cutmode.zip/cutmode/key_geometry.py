import bpy
import bmesh
from math import pi
from mathutils import Vector

# ---------------------------------------------------------------------------
# Low level mesh builders.
# Every key is built with its BASE (widest part) at Z = 0 and it extends
# towards +Z up to `height`. The caller positions/orients it with a matrix.
# `clearance` inflates the shape (used for the female socket cutter so the
# printed parts have a small tolerance gap and actually fit together).
# ---------------------------------------------------------------------------

def _finish(mesh, bm):
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(mesh)
    bm.free()


def create_prism_mesh(name, w_base, d_base, w_tip, d_tip, height, clearance=0.0):
    """Generic tapered box. Dovetail = tapered, Rectangle = no taper."""
    mesh = bpy.data.meshes.new(name)
    obj = bpy.data.objects.new(name, mesh)
    bm = bmesh.new()

    c = clearance
    h = height + c
    wb = w_base / 2 + c
    db = d_base / 2 + c
    wt = w_tip / 2 + c
    dt = d_tip / 2 + c

    verts = [
        bm.verts.new((-wb, -db, 0)),
        bm.verts.new((wb, -db, 0)),
        bm.verts.new((wb, db, 0)),
        bm.verts.new((-wb, db, 0)),
        bm.verts.new((-wt, -dt, h)),
        bm.verts.new((wt, -dt, h)),
        bm.verts.new((wt, dt, h)),
        bm.verts.new((-wt, dt, h)),
    ]
    bm.faces.new([verts[3], verts[2], verts[1], verts[0]])  # bottom
    bm.faces.new([verts[4], verts[5], verts[6], verts[7]])  # top
    bm.faces.new([verts[0], verts[1], verts[5], verts[4]])
    bm.faces.new([verts[1], verts[2], verts[6], verts[5]])
    bm.faces.new([verts[2], verts[3], verts[7], verts[6]])
    bm.faces.new([verts[3], verts[0], verts[4], verts[7]])

    _finish(mesh, bm)
    return obj


def create_dovetail_mesh(name, width, depth, height, clearance=0.0):
    # Wide at the BASE (the cut face) and narrower at the TIP so the narrow
    # end enters the opposite part and self-locates. A gentle taper (not a
    # sharp triangle) so it inserts and wedges cleanly.
    return create_prism_mesh(name, width, depth, width * 0.72, depth * 0.72,
                             height, clearance)


def create_rect_mesh(name, width, depth, height, clearance=0.0):
    # Straight rectangular key: alignment + anti-rotation.
    return create_prism_mesh(name, width, depth, width, depth, height, clearance)


def create_cone_like(name, r_base, r_tip, height, segments, clearance=0.0):
    mesh = bpy.data.meshes.new(name)
    obj = bpy.data.objects.new(name, mesh)
    bm = bmesh.new()

    c = clearance
    h = height + c
    bmesh.ops.create_cone(
        bm,
        cap_ends=True,
        cap_tris=False,
        segments=segments,
        radius1=r_base + c,
        radius2=r_tip + c,
        depth=h,
    )
    # create_cone is centred on origin -> move base to Z = 0
    bmesh.ops.translate(bm, vec=Vector((0, 0, h / 2)), verts=bm.verts)
    _finish(mesh, bm)
    return obj


def create_cylinder_mesh(name, diameter, height, clearance=0.0):
    r = diameter / 2
    return create_cone_like(name, r, r * 0.88, height, 24, clearance)


def create_hex_mesh(name, diameter, height, clearance=0.0):
    r = diameter / 2
    return create_cone_like(name, r, r * 0.9, height, 6, clearance)


def create_snap_mesh(name, diameter, height, clearance=0.0):
    """Barbed snap-fit clip: a shaft with a flared barb near the tip.
    Built as a solid of revolution (lathe) so it is a single watertight mesh."""
    mesh = bpy.data.meshes.new(name)
    obj = bpy.data.objects.new(name, mesh)
    bm = bmesh.new()

    c = clearance
    r = diameter / 2 + c
    h = height + c

    # profile: (radius, z) from the axis, out, and back to the axis
    profile = [
        (0.0, 0.0),
        (r, 0.0),
        (r, h * 0.50),
        (r * 1.35, h * 0.66),   # barb flare (undercut = the "snap")
        (r * 0.80, h * 0.80),   # neck after the barb
        (r * 0.45, h),
        (0.0, h),
    ]
    vs = [bm.verts.new((p[0], 0.0, p[1])) for p in profile]
    es = [bm.edges.new((vs[i], vs[i + 1])) for i in range(len(vs) - 1)]

    bmesh.ops.spin(
        bm,
        geom=vs + es,
        cent=(0, 0, 0),
        axis=(0, 0, 1),
        angle=2 * pi,
        steps=24,
        use_duplicate=False,
    )
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-5)
    _finish(mesh, bm)
    return obj


def generate_key_object(key_type, name, width, depth, height, clearance=0.0):
    """Dispatch. width/depth/height are ABSOLUTE Blender units already scaled
    by the caller relative to the cut face (see utils.build_joint)."""
    if key_type == 'DOVETAIL':
        return create_dovetail_mesh(name, width, depth, height, clearance)
    elif key_type == 'CYLINDER':
        return create_cylinder_mesh(name, width, height, clearance)
    elif key_type == 'SNAP':
        return create_snap_mesh(name, width, height, clearance)
    elif key_type == 'RECT':
        return create_rect_mesh(name, width, depth, height, clearance)
    elif key_type == 'HEX':
        return create_hex_mesh(name, width, height, clearance)
    return create_dovetail_mesh(name, width, depth, height, clearance)
