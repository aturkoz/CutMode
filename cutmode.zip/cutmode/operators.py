import bpy
import gpu
from gpu_extras.batch import batch_for_shader
from mathutils import Vector, Matrix
from .utils import (
    get_cutting_plane_from_screen_line,
    bisect_and_fill,
    build_joint,
    find_contact_plane,
    measure_cut_face,
)


def _settings_dict(s):
    return {
        'key_type': s.key_type,
        'scale_xy': s.scale_xy,
        'scale_z': s.scale_z,
        'clearance': s.clearance,
        'count': s.count,
        'flip': s.flip,
    }


def _next_cut_id(context):
    ids = [o.get("dovet_cut_id", 0) for o in context.scene.objects
           if "dovet_cut_id" in o]
    return (max(ids) + 1) if ids else 1


def _store_cut_data(obj, parent_name, cut_id, center, normal, size_u, size_v):
    obj["dovet_parent"] = parent_name
    obj["dovet_cut_id"] = cut_id
    obj["dovet_center"] = list(center)
    obj["dovet_normal"] = list(normal)
    obj["dovet_size_u"] = float(size_u)
    obj["dovet_size_v"] = float(size_v)


# ---------------------------------------------------------------------------
# Draw callback
# ---------------------------------------------------------------------------
def draw_callback_px(self, context):
    if len(self.mouse_path) < 2:
        return
    coords = [(p[0], p[1]) for p in self.mouse_path]
    try:
        shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
    except Exception:
        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": coords})
    gpu.state.blend_set('ALPHA')
    try:
        gpu.state.line_width_set(3.0)
    except Exception:
        pass
    shader.bind()
    shader.uniform_float("color", (1.0, 0.2, 0.2, 1.0))
    batch.draw(shader)
    try:
        gpu.state.line_width_set(1.0)
    except Exception:
        pass
    gpu.state.blend_set('NONE')


class DOVET_OT_draw_cut_line(bpy.types.Operator):
    bl_idname = "view3d.dovet_draw_cut_line"
    bl_label = "Draw Cut Line"
    bl_description = "Drag the mouse across the object to draw a cutting line"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        if context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "View3D not found")
            return {'CANCELLED'}
        if not context.active_object or context.active_object.type != 'MESH':
            self.report({'WARNING'}, "Please select a mesh object first")
            return {'CANCELLED'}

        self.mouse_path = []
        self._handle = bpy.types.SpaceView3D.draw_handler_add(
            draw_callback_px, (self, context), 'WINDOW', 'POST_PIXEL')
        context.window.cursor_modal_set('CROSSHAIR')
        self.report({'INFO'}, "Cizim modu: modelin uzerine tiklayip surukleyin.")
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def cancel(self, context):
        if self._handle:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            except Exception:
                pass
            self._handle = None
        try:
            context.window.cursor_modal_restore()
        except Exception:
            pass

    def modal(self, context, event):
        context.area.tag_redraw()

        if event.type == 'MOUSEMOVE':
            if len(self.mouse_path) > 0:
                self.mouse_path.append((event.mouse_region_x, event.mouse_region_y))

        elif event.type == 'LEFTMOUSE':
            if event.value == 'PRESS':
                self.mouse_path = [(event.mouse_region_x, event.mouse_region_y)]
            elif event.value == 'RELEASE':
                if len(self.mouse_path) == 0:
                    return {'RUNNING_MODAL'}
                if len(self.mouse_path) >= 2:
                    self.mouse_path.append((event.mouse_region_x, event.mouse_region_y))
                    self.cancel(context)
                    self.execute_cut(context)
                    return {'FINISHED'}
                else:
                    self.cancel(context)
                    return {'CANCELLED'}

        elif event.type in {'ESC', 'RIGHTMOUSE'}:
            self.cancel(context)
            return {'CANCELLED'}

        elif event.type == 'Z' and event.ctrl:
            self.cancel(context)
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def execute_cut(self, context):
        obj = context.active_object
        start = self.mouse_path[0]
        end = self.mouse_path[-1]

        plane_co, plane_no = get_cutting_plane_from_screen_line(context, start, end, obj)
        if plane_co is None or plane_no is None:
            self.report({'ERROR'}, "Could not project cut line to 3D space")
            return

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        original_name = obj.name

        obj_A = obj.copy()
        obj_A.data = obj.data.copy()
        obj_A.name = f"{original_name}_Part_A"
        context.collection.objects.link(obj_A)

        obj_B = obj.copy()
        obj_B.data = obj.data.copy()
        obj_B.name = f"{original_name}_Part_B"
        context.collection.objects.link(obj_B)

        cut_verts_A = bisect_and_fill(obj_A, plane_co, plane_no, clear_inner=False, clear_outer=True)
        cut_verts_B = bisect_and_fill(obj_B, plane_co, plane_no, clear_inner=True, clear_outer=False)

        if not cut_verts_A or not cut_verts_B:
            bpy.data.objects.remove(obj_A, do_unlink=True)
            bpy.data.objects.remove(obj_B, do_unlink=True)
            self.report({'WARNING'}, "Cut line did not intersect the object geometry")
            return

        # Exact cut face (world space) -> centre + size, from Part A's cut loop
        world_cut = [obj_A.matrix_world @ c for c in cut_verts_A]
        center, size_u, size_v = measure_cut_face(world_cut, plane_no)
        if center is None:
            center = plane_co

        cut_id = _next_cut_id(context)
        _store_cut_data(obj_A, obj.name, cut_id, center, plane_no, size_u, size_v)
        _store_cut_data(obj_B, obj.name, cut_id, center, plane_no, size_u, size_v)

        obj.hide_viewport = True
        obj.hide_render = True

        settings = context.scene.dovet_settings
        joined = False
        if settings.auto_join:
            ok, err = build_joint(context, obj_A, obj_B, center, plane_no,
                                  size_u, size_v, _settings_dict(settings))
            joined = ok
            if not ok:
                self.report({'WARNING'}, f"Cut done, but joint failed: {err}")

        bpy.ops.object.select_all(action='DESELECT')
        obj_A.select_set(True)
        obj_B.select_set(True)
        context.view_layer.objects.active = obj_A

        if joined:
            self.report({'INFO'}, "Cut + connector done.")
        else:
            self.report({'INFO'}, "Cut done. Use 'Add Connector' for the joint.")


class DOVET_OT_generate_key(bpy.types.Operator):
    bl_idname = "object.dovet_generate_key"
    bl_label = "Add Connector"
    bl_description = "Add the connector joint between the two selected cut parts"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected = context.selected_objects
        if len(selected) != 2:
            self.report({'WARNING'}, "Please select exactly two parts")
            return {'CANCELLED'}

        obj_A, obj_B = selected[0], selected[1]
        if obj_A.type != 'MESH' or obj_B.type != 'MESH':
            self.report({'WARNING'}, "Both selected objects must be meshes")
            return {'CANCELLED'}

        # Prefer the exact data stored at cut time.
        src = obj_A if "dovet_center" in obj_A else (obj_B if "dovet_center" in obj_B else None)
        if src is not None:
            center = Vector(src["dovet_center"])
            normal = Vector(src["dovet_normal"])
            size_u = float(src["dovet_size_u"])
            size_v = float(src["dovet_size_v"])
        else:
            center, normal, size_u, size_v = find_contact_plane(obj_A, obj_B)
            if center is None:
                self.report({'ERROR'}, "No contact face found. Make sure the parts touch.")
                return {'CANCELLED'}

        settings = context.scene.dovet_settings
        ok, err = build_joint(context, obj_A, obj_B, center, normal,
                              size_u, size_v, _settings_dict(settings))
        if not ok:
            self.report({'ERROR'}, f"Boolean failed: {err}")
            return {'CANCELLED'}

        bpy.ops.object.select_all(action='DESELECT')
        obj_A.select_set(True)
        obj_B.select_set(True)
        context.view_layer.objects.active = obj_A
        self.report({'INFO'}, "Connector generated successfully")
        return {'FINISHED'}


class DOVET_OT_undo_last_cut(bpy.types.Operator):
    bl_idname = "object.dovet_undo_last_cut"
    bl_label = "Undo Last Cut"
    bl_description = "Delete the most recent cut's parts and restore the original"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        cut_objs = [o for o in context.scene.objects if "dovet_cut_id" in o]
        if not cut_objs:
            self.report({'WARNING'}, "No cut parts found to undo")
            return {'CANCELLED'}

        last_id = max(o["dovet_cut_id"] for o in cut_objs)
        parts = [o for o in cut_objs if o["dovet_cut_id"] == last_id]
        parents = {o.get("dovet_parent", "") for o in parts}

        for p in parts:
            bpy.data.objects.remove(p, do_unlink=True)
        for name in parents:
            po = context.scene.objects.get(name)
            if po:
                po.hide_viewport = False
                po.hide_render = False
                po.select_set(True)
                context.view_layer.objects.active = po

        self.report({'INFO'}, "Last cut reverted")
        return {'FINISHED'}


class DOVET_OT_delete_all_cuts(bpy.types.Operator):
    bl_idname = "object.dovet_delete_all_cuts"
    bl_label = "Delete All Cuts"
    bl_description = "Delete all cut parts and restore all original objects"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        parts = [o for o in context.scene.objects if "dovet_cut_id" in o]
        if not parts:
            self.report({'WARNING'}, "No cut parts found to delete")
            return {'CANCELLED'}

        parents = {o.get("dovet_parent", "") for o in parts}
        for p in parts:
            bpy.data.objects.remove(p, do_unlink=True)
        for name in parents:
            po = context.scene.objects.get(name)
            if po:
                po.hide_viewport = False
                po.hide_render = False
                po.select_set(True)
                context.view_layer.objects.active = po

        self.report({'INFO'}, "All cuts deleted and originals restored")
        return {'FINISHED'}


class DOVET_OT_export_stl(bpy.types.Operator):
    bl_idname = "object.dovet_export_stl"
    bl_label = "Export STL"
    bl_description = "Export the selected parts as STL for 3D printing"

    filepath: bpy.props.StringProperty(subtype='FILE_PATH')
    filename_ext = ".stl"

    def invoke(self, context, event):
        if not context.selected_objects:
            self.report({'WARNING'}, "Select the parts to export first")
            return {'CANCELLED'}
        if not self.filepath:
            self.filepath = "dovetail_parts.stl"
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        path = self.filepath
        if not path.lower().endswith(".stl"):
            path += ".stl"
        try:
            # Blender 4.2+ unified exporter
            bpy.ops.wm.stl_export(filepath=path, export_selected_objects=True)
        except Exception:
            try:
                # Legacy exporter (<= 4.1)
                bpy.ops.export_mesh.stl(filepath=path, use_selection=True)
            except Exception as e:
                self.report({'ERROR'}, f"STL export failed: {e}")
                return {'CANCELLED'}
        self.report({'INFO'}, f"Exported: {path}")
        return {'FINISHED'}
