bl_info = {
    "name": "CutMode",
    "author": "ahmetturkoz",
    "version": (1, 1, 0),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar > CutMode",
    "description": "Slice 3D models and add auto-fitted connector joints (dovetail, pin, snap clip, key, hex) for 3D printing",
    "category": "Mesh",
}

import bpy
from .operators import (
    DOVET_OT_draw_cut_line,
    DOVET_OT_generate_key,
    DOVET_OT_undo_last_cut,
    DOVET_OT_delete_all_cuts,
    DOVET_OT_export_stl,
)


class DovetSettings(bpy.types.PropertyGroup):
    key_type: bpy.props.EnumProperty(
        name="Type",
        description="Connector geometry",
        items=[
            ('DOVETAIL', "Dovetail Wedge", "Tapered wedge, aligns + wedges"),
            ('CYLINDER', "Pin / Cylinder", "Round alignment pin"),
            ('SNAP',     "Snap Clip",      "Barbed snap-fit clip that locks together"),
            ('RECT',     "Rectangular Key", "Straight key, alignment + anti-rotation"),
            ('HEX',      "Hex Pin",         "Hexagonal pin, alignment + anti-rotation"),
        ],
        default='DOVETAIL',
    )

    auto_join: bpy.props.BoolProperty(
        name="Auto add connector after cut",
        description="Immediately add the connector using the exact cut data (recommended)",
        default=True,
    )

    manual: bpy.props.BoolProperty(
        name="Manual settings",
        description="Show connector settings",
        default=True,
    )

    scale_xy: bpy.props.FloatProperty(
        name="Size",
        description="Connector width relative to the cut face (1.0 = auto fit)",
        default=1.0, min=0.1, max=3.0,
    )

    scale_z: bpy.props.FloatProperty(
        name="Length",
        description="How far the peg extends, relative to its width",
        default=1.0, min=0.1, max=3.0,
    )

    clearance: bpy.props.FloatProperty(
        name="Clearance",
        description="Tolerance gap for the socket (critical for 3D-print fit)",
        default=0.15, min=0.0, max=1.5, step=1, precision=3,
    )

    count: bpy.props.IntProperty(
        name="Count",
        description="Number of connectors spread across the cut face",
        default=1, min=1, max=5,
    )

    flip: bpy.props.BoolProperty(
        name="Flip",
        description="Swap which part gets the peg and which gets the socket",
        default=False,
    )


class VIEW3D_PT_dovet_panel(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'CutMode'
    bl_label = "CutMode"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.dovet_settings

        # --- Connector settings ---
        box = layout.box()
        box.label(text="Connector", icon='MOD_BOOLEAN')
        box.prop(settings, "key_type", text="")
        row = box.row(align=True)
        row.prop(settings, "scale_xy")
        row.prop(settings, "scale_z")
        box.prop(settings, "clearance")
        box.prop(settings, "count")
        box.prop(settings, "flip")

        layout.separator()

        # --- Cut ---
        col = layout.column(align=True)
        col.label(text="1) Cut")
        col.prop(settings, "auto_join")
        col.operator("view3d.dovet_draw_cut_line", text="Draw Cut Line", icon='GREASEPENCIL')
        info = layout.column()
        info.enabled = False
        info.label(text="Drag across the part to cut")

        layout.separator()

        # --- Manual connector (two selected parts) ---
        col = layout.column(align=True)
        col.label(text="2) Add Connector (manual)")
        col.operator("object.dovet_generate_key", text="Add Connector", icon='LINKED')
        info2 = layout.column()
        info2.enabled = False
        info2.label(text="Select both halves, then click")

        layout.separator()

        # --- Export ---
        col_exp = layout.column(align=True)
        col_exp.label(text="3) Export")
        col_exp.operator("object.dovet_export_stl", text="Export STL", icon='EXPORT')

        layout.separator()

        # --- Undo / Delete ---
        col_undo = layout.column(align=True)
        col_undo.label(text="Undo")
        col_undo.operator("object.dovet_undo_last_cut", text="Undo Last Cut", icon='LOOP_BACK')
        col_undo.operator("object.dovet_delete_all_cuts", text="Delete All Cuts", icon='TRASH')

        layout.separator()

        box_credits = layout.box()
        cc = box_credits.column(align=True)
        cc.label(text="CutMode - ahmetturkoz")
        op_gh = cc.operator("wm.url_open", text="GitHub", icon='URL')
        op_gh.url = "https://github.com/aturkoz"


classes = (
    DovetSettings,
    DOVET_OT_draw_cut_line,
    DOVET_OT_generate_key,
    DOVET_OT_undo_last_cut,
    DOVET_OT_delete_all_cuts,
    DOVET_OT_export_stl,
    VIEW3D_PT_dovet_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.dovet_settings = bpy.props.PointerProperty(type=DovetSettings)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.dovet_settings


if __name__ == "__main__":
    register()
